COLLINS KIPSANG KIGEN — AUTHOR WEBSITE

Files:
- index.html — complete responsive website
- collins-photo.png — supplied author portrait

To publish:
1. Upload both files to any static website host.
2. Make sure index.html and collins-photo.png are in the same folder.
3. The website is mobile-friendly and includes Buy, Facebook, phone and email buttons.

IMPORTANT:
The Amazon short link supplied was written as:
https://a.co/d/0i4uWa4U-this

The site uses:
https://a.co/d/0i4uWa4U

because "-this" appears to be extra text rather than part of the short URL. If your actual Amazon link is different, replace that URL in index.html in the two book-button locations.

The design intentionally makes your portrait the main visual element and places multiple "Buy the Book" calls-to-action throughout the page.
